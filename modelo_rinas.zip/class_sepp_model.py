__name__ = "Class for the SEPP Model"

#%matplotlib inline
import os
import numpy as np
import math
import matplotlib.pyplot as plt
import pandas as pd
import geopandas as gpd
import gmaps
import gmaps.datasets
import scipy.stats
import random 
from scipy.optimize import fsolve
from scipy.optimize import minimize
import timeit
import datetime
from shapely import wkt
from pyproj import Proj
from shapely.geometry import Point, LineString, Polygon
from shapely.geometry import MultiPoint, MultiLineString, MultiPolygon, box
import folium
from folium import Choropleth, Circle, Marker
from folium.plugins import HeatMap, MarkerCluster
from pyproj import Proj, transform
from pyproj import Transformer
from collections import namedtuple
from sepp_auxiliar_functions import *
import fiona

class ModeloBase:
    
    def train_model(self):
        pass
       
    def predict_model(self):
        pass
    
    def validation_model(self):
        pass


class ModeloRinhas(ModeloBase):
    """
    Use the Self Exciting Point Process to Train the model (training_model). It makes a simulation of events for some 
    number of hours. It is the prediction_model. After, for the validation_model, it is used the hit rate metric.
    
    :param setting: 0 if the data are real data, 1 if the data are simulated data
    :param events_gdf: dataframe with the events data for the training model
    :param cov_norm_cell_m: array of covariates of each cell of the grid 
    :param cov_norm_eventos_m: array of covariates of each cell where the events ocurred
    :param temp_factor: temporal scale for the time data of the dataframe
    :param sp_factor: spatial scale for the spatial time as polygon area and distance between events
    :param number_hours: number of hours to simulate data or make the prediction 
    :param poligonos_df: dataframe with the polygons of each cell of grid ant its respective covariate values
    :return beta: optimization of the parameter related with the constant background rate
    :return omega: optimization of the parameter related with ocurrence of triggering events
    :return sigma2: optimization of the parameter related with the spread of triggering events
    :return puntos_gdf: dataframe with the simulated events
    :return array_cells_events_sim: two dimensional array with the number of cell and the number of events ocurred on it
    :return h_r: the validation process is make with the hit rate metric for the simulated events
    """

    def __init__(self, setting, events_gdf, cov_norm_cell_m, cov_norm_eventos_m, temp_factor, sp_factor, number_hours, poligonos_df):
        self.setting = setting
        self.events_gdf = events_gdf
        self.cov_norm_cell_m = cov_norm_cell_m
        self.cov_norm_eventos_m = cov_norm_eventos_m
        self.temp_factor = temp_factor
        self.sp_factor = sp_factor
        self.number_hours = number_hours
        self.poligonos_df = poligonos_df
        
        
    #########################################
    # Training Process (Parameter fitting) #
    ########################################
    
    def train_model(self):
        """
        Calculate the optimized values for the conditional intensity for the SEPP model
     
        :param setting: 0 if the data are real data, 1 if the data are simulated data
        :param events_gdf: dataframe with the events data for the training model
        :param cov_norm_cell_m: array of covariates of each cell of the grid 
        :param cov_norm_eventos_m: array of covariates of each cell where the events ocurred
        :param temp_factor: temporal scale for the time data of the dataframe
        :param sp_factor: spatial scale for the spatial time as polygon area and distance between events
        :return beta: optimization of the parameter related with the constant background rate
        :return omega: optimization of the parameter related with ocurrence of triggering events
        :return sigma2: optimization of the parameter related with the spread of triggering events
        """
        data = self.events_gdf
        data['X'] = data.geometry.x
        data['Y'] = data.geometry.y
        data = data.rename(columns={'X':'Lon','Y':'Lat','cells':'Cell','TimeStamp':'Time'})
        data['Time'] = pd.to_numeric(data['Time'], downcast="float").to_numpy()
        data = data[['Lon','Lat','Time','Cell']]
        xy = np.array(data.iloc[:,0:2])
        cov_norm_cell_m = self.cov_norm_cell_m
        cov_norm_eventos_m = self.cov_norm_eventos_m
        sp_factor = self.sp_factor
        d2_ev = dist2_ev(xy)
        
        if self.setting == 0:          #siedco data
            tiempo_eventos = pd.to_numeric(self.events_gdf.TimeStamp, downcast="float")
        if self.setting == 1:          #simulation data
            tiempo_eventos = pd.to_numeric(self.events_gdf.TimeStamp, downcast="float").to_numpy()
        beta = np.ones(78)[0:len(self.cov_norm_cell_m[0])]
        omega = 1
        sigma2 =  1
        T = pd.to_numeric(self.events_gdf.TimeStamp, downcast="float").to_numpy()[-1]
        sc = 0.49*sp_factor
        p = 0
        
        #============================
        #== Parameter Optimization ==
        #============================
                
        while True:
            cte1 = 1/(2 * sigma2)
            cte2 = omega /(2 * np.pi *  sigma2)
            g_ij = prob(beta, omega, sigma2, tiempo_eventos, cov_norm_eventos_m, d2_ev)[0]
            mu = prob(beta, omega, sigma2, tiempo_eventos, cov_norm_eventos_m, d2_ev)[1]
            Lambda = prob(beta, omega, sigma2, tiempo_eventos, cov_norm_eventos_m, d2_ev)[2]
            p_ij = prob(beta, omega, sigma2, tiempo_eventos, cov_norm_eventos_m, d2_ev)[3]
            pte = prob(beta, omega, sigma2, tiempo_eventos, cov_norm_eventos_m, d2_ev)[4]
            pbe = prob(beta, omega, sigma2, tiempo_eventos, cov_norm_eventos_m, d2_ev)[5]
            
            data = (T, sc, cov_norm_cell_m, cov_norm_eventos_m, pbe)
            betac = root_beta(beta,data)
            omegac = new_omega1(omega,tiempo_eventos,T,p_ij,pte)
            sigma2c = update_sigma21(sigma2,p_ij,pte,d2_ev)
            dif_beta = abs(beta-betac)
            dif_omega = abs(omega-omegac)
            dif_sigma2 = abs(sigma2-sigma2c)
            #print(dif_beta)
            #print(dif_omega)
            #print(dif_sigma2)
            if (dif_beta.all() > 1e-5) and (dif_omega > 1e-5) and (dif_sigma2 > 1e-5):
                #print('---------')
                #print(p)
                beta = betac
                omega = omegac
                sigma2 = sigma2c
                p += 1
            else:
                break
        file = open("opt_parameters.txt", "w")
        file.write(str(beta[0]) + '\n')
        file.write(str(beta[1]) + '\n')
        file.write(str(omega) + '\n')
        file.write(str(sigma2) + '\n')
        file.close()           
            
        return beta, omega, sigma2                  
        
    ##############
    # Simulation #
    ##############

    def predict_model(self, beta, omega, sigma2):
        """
        Simulate events during a time
        :param beta: weight for the covariates
        :param omega: how much decay temporally the probability of triggering event
        :param sigma2: how much spread the triggering effect from background event
        :param number_hours = time for simulating events
        :param poligonos_df = poligonos_df
        :return puntos_gdf: points of the simulate events 
        :return array_cells_events_sim: array of the simulated events and its cell number 
        :return array_cells_events_data: array of the siedco data events and its cell number
        """
        parameters = np.array([])
        filename = "opt_parameters.txt"
        with open(filename) as f_obj:
            for line in f_obj:
                parameters = np.append(parameters,float(line.rstrip()))
            
        window_size = self.number_hours/self.temp_factor
        Event = namedtuple("Event", ["t", "loc_x", "loc_y"])
        alpha = 1
        sigma = np.sqrt(sigma2)
        

        def get_random_point_in_polygon_back(poly):
            """
            Generates random background events inside a polygon
            """
            minx, miny, maxx, maxy = poly.bounds
            while True:
                p = Point(random.uniform(minx, maxx), random.uniform(miny, maxy))
                if poly.contains(p):
                    return p

        def get_random_point_in_polygon_trig(poly):
            """
            Generates random triggering events inside a polygon
            :param poly: goemetry of the polygon
            :return p: point inside of polygon
            """
            while True:
                loc_x = np.random.normal(loc=parent.loc_x, scale=sigma)
                loc_y = np.random.normal(loc=parent.loc_y, scale=sigma)
                p = Point(loc_x, loc_y)
                if poly.contains(p):
                    return p

        def sort_with_causes(points, caused_by):
            """
            Sorts events in time, and maintains caused by information
            :param points: array of events
            :parm caused_by: array with the number of the event that caused it
            :return events: sorted point array
            :return new_caused_by: sorted caused_by array
            """
            # caused_by[i] = j<i if i caused by j, or i if i background
            tagged = list(enumerate(points))
            tagged.sort(key = lambda pair : pair[1].t)
            new_caused_by = []
            for old_index, event in tagged:
                old_cause_index = caused_by[old_index]
                new_cause_index,_ = next(x for x in enumerate(tagged) if x[1][0] == old_cause_index)
                new_caused_by.append(new_cause_index)
            events = [x[1] for x in tagged]
            return events, new_caused_by

        def simulate_sub_process(parent : Event, k):
            """
            Generates the triggered events
            :param parent : Event: parent event
            :param k: number of cell where ocurred the event
            """
            points = []
            t = 0
            while True:
                t += np.random.exponential(1/omega)
                if t >= alpha:
                    return points
                def get_random_point_in_polygon_trig(poly):
                    while True:
                        loc_x = np.random.normal(loc=parent.loc_x, scale=sigma)
                        loc_y = np.random.normal(loc=parent.loc_y, scale=sigma)
                        p = Point(loc_x, loc_y)
                        if poly.contains(p):
                            return p
                p = get_random_point_in_polygon_trig(self.poligonos_df.geometry[k])
                loc_x = p.x
                loc_y = p.y
                points.append(Event(parent.t + np.log(alpha/abs(alpha-t*omega))/omega , loc_x, loc_y))

        def _add_point(points, omega):
            """
            Generates interarrival times between consecutive events and adds it to a list
            :param points: list of points
            :param mu: events rate for the cell
            """
            wait_time = np.random.exponential(1/omega)
            if len(points) == 0:
                last = 0
            else:
                last = points[-1]
            points.append(last + wait_time)
        
        def sample_poisson_process_hom(window_size, omega):
            """
            Generates the background events according to the background events rate in some window temporal size 
            :param window_size: window temporal size
            :param mu: background events rate
            :return points: simulated background points
            """
            #points = []
            #_add_point(points, omega)
            #while points[-1] < window_size:
            #    _add_point(points, omega)
            #return points
            
            points = []
            _add_point(points, omega)
            while points[-1] < window_size:
                _add_point(points, omega)
            return points

        def simulate(window_size, k):
            """
            Generates the background events with their descendant events in some window temporal size in one cell
            :param window_size: window temporal size
            :param k: number of cell
            :return puntos_gdf: dataframe with the simulated events
            :return array_cells_events_sim: two dimensional array with cell number and its corresponding number of events
            """
            backgrounds = sample_poisson_process_hom(window_size, mu[k])
            backgrounds = backgrounds[:-1]
            points = []
            for i in range(0, len(backgrounds)):
                t = backgrounds[i]
                p = get_random_point_in_polygon_back(self.poligonos_df.geometry[k])
                px = p.x
                py = p.y
                st_point = Event(t, px, py)
                points.append(st_point)
            backgrounds = points    
            caused_by = [ i for i in range(len(points))]
            to_process = [(i,p) for i, p in enumerate(points)]
            while len(to_process) > 0:
                (index, next_point) = to_process.pop()
                for event in simulate_sub_process(next_point,k):
                    if event.t < window_size:
                        points.append(event)
                        caused_by.append(index)
                        to_process.append((len(points) - 1,event))
            points, caused_by = sort_with_causes(points, caused_by)
            return points,  backgrounds, caused_by

        events_sim_on_cells = np.array([])
        all_events_sim = np.array([])

        mu = np.exp((beta*self.cov_norm_cell_m).sum(axis=1).astype(float))
               
        for k in range(0, len(self.cov_norm_cell_m)):
            
            ev = simulate(window_size, k)[0]
            # events of all cells
            all_events_sim = np.append(all_events_sim, ev)
            # number of event per cell
            events_sim_on_cells = np.array(np.append(events_sim_on_cells, len(ev)),int)
        
        # simulated events on cells (number of events on each cell) (t,x,y) each event   
        all_events_sim = all_events_sim.reshape(int(len(all_events_sim)/3), 3)
        
        puntos_gdf = gpd.GeoDataFrame(all_events_sim, columns=["TimeStamp", "X", "Y"])
        geometry = [Point(xy) for xy in zip(puntos_gdf['X'], puntos_gdf['Y'])]
        crs = {'init': 'epsg:3857'}
        puntos_gdf = gpd.GeoDataFrame(puntos_gdf, crs=crs, geometry=geometry)
        puntos_gdf = puntos_gdf.sort_values('TimeStamp').reset_index().drop(columns = 'index')
        
        array_cells_events_sim = np.arange(0, len(events_sim_on_cells), 1).tolist()
        array_cells_events_sim = list(map(list,zip(array_cells_events_sim,events_sim_on_cells)))
        
        #puntos_gdf.to_file("prediction_events.geojson", driver='GeoJSON')
        
        return puntos_gdf, array_cells_events_sim

    
    ##############
    # Validation #
    ##############

    def validation_model(self, number_ev_pred_on_hotspots_sum, total_ev_pred):
        """
        Calculate the hit rate for the coveraged area for the simulated events
        :param sim_points_filtered: two dimensional array with filtered events according to the porcentage area covered
        :param sim_points_without_filtered: two dimensional array with events without filtered
        :return h_r: hit rate metric for the simulated events
        """
        h_r = number_ev_pred_on_hotspots_sum/total_ev_pred
        
        return h_r