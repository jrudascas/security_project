from timeit import default_timer as timer
from datetime import datetime
from sepp_auxiliar_functions import *
from class_sepp_model import *
import fiona

                                                ##########
                                                ## DATA ##
                                                ##########

data = Data()[0]
poly = Data()[1]

init_date = '2018-01-01 02:00:00'
final_date = '2018-01-01 02:09:59'
date_format_str = '%Y-%m-%d %H:%M:%S'
start = datetime.datetime.strptime(init_date, date_format_str)
end =  datetime.datetime.strptime(final_date, date_format_str)
diff = end - start

train_data1 = training_data('2018-01-01 00:00:00', '2018-01-01 01:59:59', data)
tst_data1 = test_data(init_date, final_date, data)

data_train = [train_data1]
data_test = [tst_data1]

array_events_polyg_train = cov_join_events(data_train[0], poly)
array_events_polyg_test = cov_join_events(data_test[0], poly)
temp_factor, sp_factor = 1, 0.1
number_hours = diff.total_seconds()/3600

sepp_mod = ModeloRinhas(0, array_events_polyg_train[3], array_events_polyg_train[0], array_events_polyg_train[1], temp_factor, sp_factor, number_hours, poly)

                                    ##############
                                    ## TRAINING ##
                                    ##############

train = sepp_mod.train_model()


                                    ################
                                    ## PREDICTION ##
                                    ################

prediction = sepp_mod.predict_model(train[0], train[1], train[2])

                                    ################
                                    ## VALIDATION ##
                                    ################

array_cells_events_tst_data_cells = arr_cells_events_data(array_events_polyg_test[3], prediction[1])
fil = filtering_data(20,array_cells_events_tst_data_cells, prediction[1], prediction[0],poly, init_date)

validation = sepp_mod.validation_model(fil[0], fil[1])